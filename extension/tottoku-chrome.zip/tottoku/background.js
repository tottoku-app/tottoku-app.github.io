// とっとく：今のページ（または右クリックしたリンク・画像のページ）を、ブラウザ版のとっとくに渡して保存する
// ページの中身は読みません。住所（URL）だけを渡します
const APP = "https://tottoku-app.jp/app/?save=";
const open = (url) => {
  if (!/^https?:\/\//.test(url || "")) return;
  chrome.tabs.create({ url: APP + encodeURIComponent(url) });
};

chrome.action.onClicked.addListener((tab) => open(tab.url));

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: "page", title: "このページをとっとくに保存", contexts: ["page"] });
  chrome.contextMenus.create({ id: "link", title: "このリンクをとっとくに保存", contexts: ["link"] });
});
chrome.contextMenus.onClicked.addListener((info, tab) => open(info.menuItemId === "link" ? info.linkUrl : tab?.url));
